<!--
    Инструкция по запуску:
    1. Установите зависимости: pip install flask flask-wtf
    2. Запустите приложение:
        export FLASK_APP=wtf
        flask run
    3. Откройте http://localhost:5000/ для тестирования форм на Flask-WTF.

    Документация:
    - Flask: https://flask.palletsprojects.com/
    - Flask-WTF: https://flask-wtf.readthedocs.io/
    - WTForms: https://wtforms.readthedocs.io/
-->
